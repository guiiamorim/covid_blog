create view vw_dadoslog as
select `ul`.`codLog`        AS `codLog`,
       `ul`.`tabela`        AS `tabela`,
       `ul`.`texto`         AS `texto`,
       `ul`.`tipo`          AS `tipo`,
       `ul`.`dataCadastro`  AS `dataAlteracao`,
       `f`.`codFuncionario` AS `codFuncionario`,
       `f`.`codSetor`       AS `codSetor`,
       `f`.`login`          AS `login`,
       `f`.`acesso`         AS `acesso`,
       `f`.`ordemIcones`    AS `ordemIcones`,
       `f`.`bloqueio`       AS `bloqueio`,
       `f`.`gerente`        AS `gerente`,
       `f`.`visivel`        AS `visivel`,
       `f`.`dataCriacao`    AS `dataCriacao`,
       `p`.`codPessoa`      AS `codPessoa`,
       `p`.`nome`           AS `nome`,
       `p`.`cpf`            AS `cpf`,
       `p`.`rg`             AS `rg`,
       `p`.`endereco`       AS `endereco`,
       `p`.`numero`         AS `numero`,
       `p`.`complemento`    AS `complemento`,
       `p`.`bairro`         AS `bairro`,
       `p`.`cidade`         AS `cidade`,
       `p`.`estado`         AS `estado`,
       `p`.`cep`            AS `cep`,
       `p`.`dataCadastro`   AS `dataCadastro`,
       `p`.`tipoPessoa`     AS `tipoPessoa`,
       `p`.`sexo`           AS `sexo`,
       `p`.`pessoaFisica`   AS `pessoaFisica`
from ((`demotoship_db`.`usuariolog` `ul` join `demotoship_db`.`funcionario` `f` on (`f`.`codFuncionario` = `ul`.`codFuncionario`))
         join `demotoship_db`.`pessoa` `p` on (`p`.`codPessoa` = `f`.`codPessoa`))
order by `ul`.`dataCadastro` desc;

