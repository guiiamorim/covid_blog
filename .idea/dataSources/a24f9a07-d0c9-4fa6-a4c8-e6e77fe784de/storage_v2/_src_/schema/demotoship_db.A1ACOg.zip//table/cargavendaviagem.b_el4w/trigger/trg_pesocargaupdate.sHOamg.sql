create definer = root@localhost trigger trg_pesocargaupdate
    after update
    on cargavendaviagem
    for each row
BEGIN
	UPDATE 
		carga 
	SET 
		pesoTotal = (
			SELECT 
				COALESCE(SUM(v.pesoTotal), 0) 
			FROM 
				venda v 
                INNER JOIN cargavendaviagem cvv ON (v.codVenda = cvv.codVenda) 
			WHERE 
				cvv.codCarga = OLD.codCarga AND codViagem IS NULL AND v.codStatus = 5
		)
	WHERE 
		codCarga = OLD.codCarga;
        
	IF NEW.codViagem IS NOT NULL THEN
		UPDATE 
			viagem 
		SET 
			pesoTotal = (
				SELECT 
					COALESCE(SUM(v.pesoTotal), 0) 
				FROM 
					venda v 
					INNER JOIN cargavendaviagem cvv ON (v.codVenda = cvv.codVenda) 
				WHERE 
					cvv.codCarga = OLD.codCarga AND codViagem = NEW.codViagem
			)
		WHERE 
			codViagem = NEW.codViagem;
	END IF;
END;

