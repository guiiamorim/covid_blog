create view vw_dadosmotorista as
select `p`.`codPessoa`    AS `codPessoa`,
       `p`.`nome`         AS `nome`,
       `p`.`cpf`          AS `cpf`,
       `p`.`rg`           AS `rg`,
       `p`.`endereco`     AS `endereco`,
       `p`.`numero`       AS `numero`,
       `p`.`complemento`  AS `complemento`,
       `p`.`bairro`       AS `bairro`,
       `p`.`cidade`       AS `cidade`,
       `p`.`estado`       AS `estado`,
       `p`.`cep`          AS `cep`,
       `p`.`dataCadastro` AS `dataCadastro`,
       `p`.`tipoPessoa`   AS `tipoPessoa`,
       `p`.`sexo`         AS `sexo`,
       `p`.`pessoaFisica` AS `pessoaFisica`,
       `m`.`codMotorista` AS `codMotorista`,
       `m`.`cnh`          AS `cnh`,
       `m`.`categoriaCnh` AS `categoriaCnh`
from (`demotoship_db`.`pessoa` `p`
         join `demotoship_db`.`motorista` `m` on (`p`.`codPessoa` = `m`.`codPessoa`));

