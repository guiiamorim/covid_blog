create definer = root@localhost trigger trg_pesocargadelete
    after delete
    on cargavendaviagem
    for each row
BEGIN
	UPDATE 
		carga 
	SET 
		pesoTotal = (
			SELECT 
				SUM(v.pesoTotal) 
			FROM 
				venda v 
                INNER JOIN cargavendaviagem cvv ON (v.codVenda = cvv.codVenda) 
			WHERE 
				cvv.codCarga = OLD.codCarga AND codViagem IS NULL AND v.codStatus = 5
		)
	WHERE 
		codCarga = OLD.codCarga;
        
	IF OLD.codViagem IS NOT NULL THEN
		UPDATE 
			viagem 
		SET 
			pesoTotal = (
				SELECT 
					COALESCE(SUM(v.pesoTotal), 0) 
				FROM 
					venda v 
					INNER JOIN cargavendaviagem cvv ON (v.codVenda = cvv.codVenda) 
				WHERE 
					cvv.codCarga = OLD.codCarga AND codViagem = OLD.codViagem
			)
		WHERE 
			codViagem = OLD.codViagem;
	END IF;
END;

