create view vw_dadosfazenda as
select `f`.`codFazenda`        AS `codFazenda`,
       `f`.`nomeFazenda`       AS `nomeFazenda`,
       `f`.`inscricaoEstadual` AS `inscricaoEstadual`,
       `f`.`codCidade`         AS `codCidade`,
       `f`.`logradouro`        AS `logradouro`,
       `f`.`codVendedor`       AS `codVendedor`,
       `f`.`dataLiberacao`     AS `dataLiberacao`,
       `f`.`dataCriacao`       AS `dataCriacao`,
       `f`.`codCliente`        AS `codCliente`,
       `p`.`codPessoa`         AS `codPessoa`,
       `p`.`nome`              AS `nome`,
       `p`.`cpf`               AS `cpf`,
       `p`.`rg`                AS `rg`,
       `p`.`endereco`          AS `endereco`,
       `p`.`numero`            AS `numero`,
       `p`.`complemento`       AS `complemento`,
       `p`.`bairro`            AS `bairro`,
       `p`.`cidade`            AS `cidade`,
       `p`.`estado`            AS `estado`,
       `p`.`cep`               AS `cep`,
       `p`.`dataCadastro`      AS `dataCadastro`,
       `p`.`tipoPessoa`        AS `tipoPessoa`,
       `p`.`sexo`              AS `sexo`,
       `p`.`pessoaFisica`      AS `pessoaFisica`
from (`demotoship_db`.`fazenda` `f`
         join `demotoship_db`.`pessoa` `p` on (`f`.`codCliente` = `p`.`codPessoa`));

