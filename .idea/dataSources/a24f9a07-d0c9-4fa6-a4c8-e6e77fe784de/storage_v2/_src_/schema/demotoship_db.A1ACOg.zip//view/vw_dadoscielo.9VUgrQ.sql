create view vw_dadoscielo as
select `fp`.`codFormaPagamento`      AS `codFormaPagamento`,
       `fp`.`descricao`              AS `descricao`,
       `fp`.`tipoPagamento`          AS `tipoPagamento`,
       `fp`.`status`                 AS `status`,
       `fp`.`codConta`               AS `codConta`,
       `c`.`codCielo`                AS `codCielo`,
       `c`.`merchantId`              AS `merchantId`,
       `c`.`merchantKey`             AS `merchantKey`,
       `c`.`capturarAutomaticamente` AS `capturarAutomaticamente`
from (`demotoship_db`.`formapagamento` `fp`
         join `demotoship_db`.`cielo` `c` on (`fp`.`codFormaPagamento` = `c`.`codFormaPagamento`));

