create definer = root@localhost trigger trg_vendalistadelete
    after delete
    on vendalista
    for each row
BEGIN
    
    DECLARE  INT;
    
	UPDATE 
		venda 
	SET 
		valorTotal = (
			SELECT 
				SUM(precoVenda)
			FROM 
				vendalista vl 
			WHERE
				vl.codVenda = OLD.codVenda
		), 
        pesoTotal = (
			SELECT 
				SUM(peso * quantidade) 
			FROM 
				vendalista vl INNER JOIN peso p ON (p.codPeso = vl.codPeso)
			WHERE 
				vl.codVenda = OLD.codVenda
        ),
        valorFrete = (
			SELECT 
				SUM(frete * quantidade) 
			FROM 
				vendalista vl
			WHERE
				vl.codVenda = OLD.codVenda
        ),
        comissaoTotal = (
			SELECT 
				SUM(comissao)
			FROM
				vendalista vl 
			WHERE
				vl.codVenda = OLD.codVenda
        ),
        taxaComissao = (
			SELECT
				(SUM(comissao) / SUM(precoVenda))  
			FROM
				vendalista vl
			WHERE
				vl.codVenda = OLD.codVenda
        )
	WHERE 
		codVenda = OLD.codVenda;
    
    SELECT codCarga INTO  FROM cargavendaviagem WHERE codVenda = OLD.codVenda;
    
    UPDATE 
		carga 
	SET 
		pesoTotal = (
			SELECT 
				SUM(v.pesoTotal) 
			FROM 
				venda v 
                INNER JOIN cargavendaviagem cvv ON (v.codVenda = cvv.codVenda) 
			WHERE 
				cvv.codCarga =  AND codViagem IS NULL AND v.codStatus = 5
		)
	WHERE 
		codCarga = ;

END;

