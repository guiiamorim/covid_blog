create definer = root@localhost trigger trg_pedidoupdate
    after update
    on venda
    for each row
BEGIN
	IF NEW.valorTotal <> OLD.valorTotal THEN
		DELETE FROM faturaparcela WHERE codFatura = (SELECT codFatura FROM fatura WHERE codVenda = NEW.codVenda);
        DELETE FROM fatura WHERE codVenda = NEW.codVenda;
	END IF;
END;

