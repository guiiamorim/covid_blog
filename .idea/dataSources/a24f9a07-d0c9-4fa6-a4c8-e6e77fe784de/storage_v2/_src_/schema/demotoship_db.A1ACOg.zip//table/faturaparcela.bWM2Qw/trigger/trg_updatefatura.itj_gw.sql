create definer = root@localhost trigger trg_updatefatura
    after update
    on faturaparcela
    for each row
BEGIN
	DECLARE _parcelasAtrasadas INT;
    DECLARE _parcelasQuitadas INT;
    DECLARE _totalParcelas INT;
    
    SELECT COUNT(codParcela) INTO _parcelasAtrasadas FROM faturaparcela WHERE codFatura = NEW.codFatura AND DATEDIFF(dataVencimento, CURDATE()) < 0 AND status LIKE 'ON';
    SELECT COUNT(codParcela) INTO _parcelasQuitadas FROM faturaparcela WHERE codFatura = NEW.codFatura AND status LIKE 'OFF';
    SELECT COUNT(codParcela) INTO _totalParcelas FROM faturaparcela WHERE codFatura = NEW.codFatura;
    
    IF _parcelasAtrasadas > 0 THEN
		UPDATE fatura SET codStatusFinanceiro = (SELECT codStatusFinanceiro FROM vendastatusfinanceiro WHERE sigla LIKE 'at') WHERE codFatura = NEW.codFatura;
	ELSEIF _parcelasQuitadas < _totalParcelas AND _parcelasQuitadas > 0 THEN
		UPDATE fatura SET codStatusFinanceiro = (SELECT codStatusFinanceiro FROM vendastatusfinanceiro WHERE sigla LIKE 'p') WHERE codFatura = NEW.codFatura;
	ELSEIF _parcelasQuitadas = _totalParcelas THEN
		UPDATE fatura SET codStatusFinanceiro = (SELECT codStatusFinanceiro FROM vendastatusfinanceiro WHERE sigla LIKE 'f') WHERE codFatura = NEW.codFatura;
	ELSE
		UPDATE fatura SET codStatusFinanceiro = (SELECT codStatusFinanceiro FROM vendastatusfinanceiro WHERE sigla LIKE 'a') WHERE codFatura = NEW.codFatura;
	END IF;
END;

